import java.util.Random;

public class XGrid
{
    public static final int ROWS = 4;
    public static final int COLUMNS = 5;
    public static final int RED = 0;
    public static final int BLUE = 1;
    public static final int BLACK = 2;
    public static final int GREEN = 3;

    private Random gen;
     private int x;
    private int y;
    private Color color;
    public static final int HEIGHT = 20;
    public static final int WIDTH = 15;
    public XGrid(int theX, int theY)
    {
        gen = new Random(54319577);
        x = theX;
        y = theY;
    }
    public void draw()
    {
        for (int i = 0; i < COLUMNS; i++)
        {
        Line line1 = new Line(x, y, x + WIDTH, y + HEIGHT);
        Line line2 = new Line(x + WIDTH, y, x , y + HEIGHT);
        line1.setColor(Color.RED);
        line2.setColor(Color.RED);
        line1.draw();
        line2.draw();
        
        x = x + WIDTH;
    }
    }
}
