import java.util.ArrayList;
/**
 * Models a list of vocabulary words
 */
public class Vocab
{
    private ArrayList<String> words = new ArrayList<String>(); 
    
    /**
     * intialize the arratlist of words
     * @param word intialiaze and add the words array list 
     */
    public Vocab(ArrayList<String> word)
    {
       
       words = word;
        
    }
    

    /**
     * get the longest word from words
     * @return the longest word 
     */
    public String longest()
    {
        return null;
    }

    /**
     * get the avaereage length of the words of arraylist 
     * @return the number of average length of words
     */
    public int averageLength()
    {
        return 0;
    }

    /**
     * remove the String from the arratlist 
     * @param target to remove from arrya list  
     */
    public void remove (String target)
    {
    }

    /**
     * get the string of 
     * @return String after removing words
     */

    @Override
    public String toString()
    {
        return words.toString();
    }
}
