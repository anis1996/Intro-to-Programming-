
/**
 * Processes first and last letters of words
 */
public class StartToFinish
{
    private String phrase;

    /**
     * Constructs a StartToFinish objec
     * @param myString the phase for this object
     */
    public StartToFinish(String myString)
    {
        phrase = myString;
    }

    /**
     * get the first letter of the string 
     * @return the first letter of the string 
     */
    public String firstLetters()
    {

        if (phrase.equals(""))
        {
            return "";
        }else 
        { 
            return phrase.substring(0,1);
        } 
    }

    /**
     * get the last letter of every word and make a string including those words
     * @return last letter of every word in string
     */
    public String lastLetters()
    {
        return null;
    }

}