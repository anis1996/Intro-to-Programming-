/**
 * Methods for loop pratice
 */
public class SomeLoops
{

    public int sumEveryThird(int limit)
    {
        return 3 + 6 + 9 + 12 + 18;
    }
}
