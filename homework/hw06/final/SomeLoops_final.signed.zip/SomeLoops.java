/**
 * Methods for loop pratice
 */
public class SomeLoops
{
    public String countSJSU(int count)
    {
        String c =""; 
        for( int i= 0; i < count ; i++)
        {
            c = c + " SJSU";
        }
        return c ;
    }

    public int sumEveryThird(int limit)
    {
        int number = 0;
        for ( int i = 1; i < limit ; i++)
        {
            if (i % 3 == 0 && i % 5 != 0 )
            { 
                number = number + i;
            }

        }
        return number;
    }

    public String noXYZ(String s)
    {
        String words = "";
        for (int i = 0 ; i < s.length(); i++)
        {   
            if (!"xyzXYZ".contains(s.substring(i,i+1)))
            {
                words = words + s.substring(i,i+1);
            }

        }
        return words ;
    }
}
