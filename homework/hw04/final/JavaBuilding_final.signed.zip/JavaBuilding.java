/**
 * compute the total cost of painting the JavaBuilding 
 */
public class JavaBuilding
{
    public static final double PAINT_COST_PER_GALLON = 32.27;
    public static final int SQUARE_FEET_PER_GALLON = 400;
    private double x;
    private double totalCost;
    private double area;
    /**
     * constructs a JavaBuliding with given dimension
     * @param dimension the dimension of Javabuilding 
     */
    public JavaBuilding(double dimension){
        this.x = dimension;

    }

    /**
     * get the surface area of the JavaBuilding 
     * @return the surface area
     */
    public double getSurfaceArea(){
        area = 10*(x)*x;
        return area;
    }

    /**
     * get total cost of painting the Javabuilding 
     * @return total cost of painting 
     */
    public double getCost(){
        totalCost = PAINT_COST_PER_GALLON *(area/SQUARE_FEET_PER_GALLON);
        return totalCost;
    }

    /**
     * increase the size of dimension by given amount
     * @param amount amount to add in dimension
     */
    public void increaseSide(double amount){
        this.x = this.x + amount;
    }

}