import java.util.Scanner;

public class TipCalculator
{
   public static void main(String[] args)
   {
      Scanner in = new Scanner(System.in);

      System.out.print("What was the cost of your cruise? ");
      double cost = in.nextDouble();
      System.out.print("What was quality of service? 0 is poor and 3 is excellent: ");
      double service = in.nextInt();
      System.out.println(cost + " " + service);
   }
}