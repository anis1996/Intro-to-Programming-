import java.util.Arrays;
/**
 * encapsulates a array and arraylist  and provides method to manupulate it
 */
public class Util
{
    /**
     * check the all element in the given array and find maximu value
     * @param array to check the array 
     * @return the maximum value in array 
     */
    public static int max(int[] array)
    {
        int largest = array[0]; 
        for (int i = 0; i < array.length ; i++)
        {
            if (array[i] > largest)
            {
                largest = array[i];
            }
        }
        return largest;
    }

}