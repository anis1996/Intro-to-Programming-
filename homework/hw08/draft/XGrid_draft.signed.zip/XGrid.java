import java.util.Random;

public class XGrid
{
    public static final int ROWS = 4;
    public static final int COLUMNS = 5;
    public static final int RED = 0;
    public static final int BLUE = 1;
    public static final int BLACK = 2;
    public static final int GREEN = 3;
    public static final int HEIGHT = 20;
    public static final int WIDTH = 15;
    private int x ;
    private int y ;
    private Random gen;
    public XGrid(int theX, int theY)
    {
        gen = new Random(54319577);
        x = theX;
        y = theY;
    }

    public void draw()
    {
        for (int i = 0; i < COLUMNS; i++ )
        {
            X xGrid = new X(x + (i*WIDTH),y,Color.RED);
            xGrid.draw();         
        }
    }
}