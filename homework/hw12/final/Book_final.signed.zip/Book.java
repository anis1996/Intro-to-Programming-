/**
 * book class has few methods to control the books information
 */
public class Book extends Product
{
    private String author;
    /**
     * intialize the desripstion price and author 
     * @param description to intialize 
     * @param price to intilaize 
     * @param author to intilaize 
     */
    public Book(String description, double price, String author)
    {
        super(description,price);
        this.author = author;

    }

    /**
     * get the author name 
     * @return author name 
     */
    public String getAuthor()
    {
        return author;
    }

    /**
     * check the author of two books is same 
     * @param other to check the author 
     * @return the false if author aren't same and true if author are same.
     */
    public boolean sameAuthor(Book other)
    {
        if(author.equals(other.getAuthor()))
        {
            return true;
        }else 
        {
            return false;
        }
    }

    /**
     * get the description of book
     * @return the description
     */
    public String getDescription()
    {
        return  super.getDescription() + " " + author  ;
    }
}