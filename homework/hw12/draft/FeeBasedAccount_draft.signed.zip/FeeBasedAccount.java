/**
 * type and subclass of bankaccount which oprate the account by fee 
 */
public class FeeBasedAccount extends BankAccount
{
    public static final double FEE = 2.0;
    public static final int FREE_TRANSACTIONS = 3;
    private int count;
    public FeeBasedAccount(double balance, String id)
    {
        super(balance, id);
        count = 0;      
    }
            
    public void withdraw(double money)
    {
        super.withdraw(money);
        count++;
    }
    
     public void deposit(double money)
    {
        super.deposit(money);
        count++;
    }

    public void endOfMonth()
    {
        if (count > FREE_TRANSACTIONS)
        {
            double charge = (count - FREE_TRANSACTIONS) * FEE;
            super.withdraw(charge);
        }
        
    }
}