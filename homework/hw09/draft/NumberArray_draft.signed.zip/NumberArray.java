import java.util.Arrays;
/**
 * Encapsulates an integr array and provides methods
 * to manipulate it
 */
public class NumberArray
{
    private int[] data;
    /**
     * intilaize the array 
     * @param data to intilaize the data 
     */
    public NumberArray(int[] data)
    {
        this.data = data;
    }
    /**
     * get the last element in the array 
     * @return the last element 
     */
    public int getLast()
    {
        return data[data.length-1] ;
    }
    /**
     * swap the elements 
     * @param index1 to swap with index2
     * @param index2 to swap with index1
     */
    public void swap(int index1, int index2)
    {
    }
    /**
     * check the element is in the array or not 
     * @param target to check element 
     * @return boolean false if there is not any mathcing array 
     */
    public boolean contains(int target)
    {
        return false;
    }
    /**
     * get the product of array 
     * @return the product of array 
     */
    public int product()
    {
        return 0;
    }
    /**
     *@return the String 
     */

    @Override
    public String toString()
    {
        return Arrays.toString(data);
    }
}
