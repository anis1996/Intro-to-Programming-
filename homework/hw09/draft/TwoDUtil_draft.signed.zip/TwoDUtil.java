import java.util.Arrays;
/**
 * encapsulates a 2d array of Strings and provides method to manupulate it
 */
public class TwoDUtil
{
    private String[][] twoArray ;
    /**
     * intilaize the 2dArray
     * @param array to intilaize the 2dArray
     */
    public TwoDUtil(String[][] array)
    {
        twoArray = array;         
    }

    /**
     * get the shortest string from 2dArray
     * @return shortest string 
     */
    public String shortest() 
    {return null;
    }

    /**
     * get the words in lastColumn with diving *   
     * @return words in lastColumn with diving *
     */
    public String lastColumn() 
    {
        return null;
    }

    /**
     * check the word how many times appear in the 2dArray
     * @param letter to check the words 
     * @return number of words appear in the 2dArray
     */
    public int howMany(char letter)
    {
        return 0;
    }

}