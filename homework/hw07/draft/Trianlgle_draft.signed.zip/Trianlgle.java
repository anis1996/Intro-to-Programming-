import java.util.Scanner;

public class Trianlgle
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        boolean b = false;
        int num = 0 ;
        while(!b)
        {
            System.out.print("How many rows in the triangle? ");
            if (in.hasNextInt())
            {
                num = in.nextInt();
                if (num > 0)
                {
                    b = true;
                }
            }else
            {
                in.next();
            }
        }
        System.out.print(num);
    }
}