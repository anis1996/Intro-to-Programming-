/**
 * Prints the word girl ienglish, Spanish and German.
 * 
 * @author Kathleen O'Brien 
 */
public class GirlPrinter
{
    public static void main(String[] args)
    {
System.out.println("|*******|");
        System.out.println("|girl***|");
        System.out.println("|ni\u00f1a***|");
        System.out.println("|M\u00E4dchen|");
System.out.println("|*******|");

    }
}
