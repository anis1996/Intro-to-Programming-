/**
 * Prints the word girl ienglish, Spanish and German.
 * 
 * @author Kathleen O'Brien 
 */
public class GirlPrinter
{
    public static void main(String[] args)
    {
 System.out.println("|*******|");
        System.out.println("|girl***|");

    }
}
