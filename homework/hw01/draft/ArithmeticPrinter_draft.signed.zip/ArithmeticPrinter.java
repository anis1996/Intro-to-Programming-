/**
 * Do some arithmetic in the println statement.
 * 
 * @author Kathlen O'Brien
 */
public class ArithmeticPrinter
{
   public static void main(String[] args)
   {
 System.out.println(1+2+3+4+5);
   }
}
