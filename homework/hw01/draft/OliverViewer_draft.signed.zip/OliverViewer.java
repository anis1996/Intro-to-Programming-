/**
 * Draws a bigger image of my cat Oliver
 * 
 * @author (ANIS DHAPA) 
 */
public class OliverViewer
{
    public static void main(String[] args)
    {
 Picture cat = new Picture("oliver.jpg");
        
        cat.draw ();
    }
}
