/**
 * a shoppingcart has a subtotal that can be changed by add and remove item's cost.
 */
public class ShoppingCart
{
    private double subTotal;
    /**
     * construct a shoppingcart with a zero subtotal
     */    
    public ShoppingCart()
    {   
        subTotal=0;
    }   
    
}
