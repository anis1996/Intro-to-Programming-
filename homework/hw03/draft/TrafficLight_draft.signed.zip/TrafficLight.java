/**
 * a trafficlight that draw traffic lights at diffrent places  
 */
public class TrafficLight
{
    private int x;
    private int y; 
    private int width = 20;
    private int height = 60;
    /**
     * construct a TrafficLight with given x and y points.
     * @param xPoint intialize x point 
     * @param yPoint intialize y point
     */
    public TrafficLight(int xPoint, int yPoint){
        x = xPoint;
        y = yPoint;
    }

    /**
     * draw TrafficLights at diffrent points 
     */
    public void draw(){
        Rectangle box = new Rectangle (x, y, width, height);
        box.draw();
        }
}