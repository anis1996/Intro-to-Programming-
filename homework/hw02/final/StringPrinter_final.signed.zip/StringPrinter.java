public class StringPrinter
{

   public static void main(String[] args)
   {
       String word = "separate"; 
       int wordlength  = word.length();
       System.out.println(2*wordlength);
       System.out.println(word.toUpperCase());
       String replacement = word.replace("t","7");
       String replacement2 = replacement.replace("a","4");
       String replacement3 = replacement2.replace("e","3");
       System.out.println(replacement3);
       System.out.println(word);
   }
}