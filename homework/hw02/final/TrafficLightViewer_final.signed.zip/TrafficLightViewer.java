public class TrafficLightViewer
{
    public static void main(String[] args)
    {

     Rectangle box = new Rectangle(50, 20, 20, 60);
     box.draw();
     Ellipse redCircle = new Ellipse(50, 20, 20, 20);
     redCircle.setColor(Color.RED);
     redCircle.fill();
     Ellipse yellowCircle = new Ellipse(50, 40, 20, 20);
     yellowCircle.setColor(Color.YELLOW);
     yellowCircle.fill();
     Ellipse greenCircle = new Ellipse(50, 60, 20, 20);
     greenCircle.setColor(Color.GREEN);
     greenCircle.fill();

    }
}

