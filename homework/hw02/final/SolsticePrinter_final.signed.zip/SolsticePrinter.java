/**
 * Prints how many days until the winter solstice
 * @author 
 */
public class SolsticePrinter
{
    public static void main(String[] args)
    {
        Day today = new Day ();
        System.out.println("Today is " + today.toString());
        Day wintersolstice = new Day(2016, 12, 21);
        int daysfromtoday = wintersolstice.daysFrom(today);
        System.out.println(daysfromtoday);
        today.addDays (100);
        System.out.println(today.getYear());
        System.out.println(today.getMonth());
        System.out.println(today.getDayOfMonth());
    }
}
