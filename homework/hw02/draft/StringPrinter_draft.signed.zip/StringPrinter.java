public class StringPrinter
{

   public static void main(String[] args)
   {
       String word = "separate"; //do not chnage this line
       int wordlength  = word.length();
       System.out.println(2*wordlength);

       //your code goes here

   }
}