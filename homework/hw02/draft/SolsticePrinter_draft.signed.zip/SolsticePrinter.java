/**
 * Prints how many days until the winter solstice
 * @author 
 */
public class SolsticePrinter
{
    public static void main(String[] args)
    {
        Day today = new Day ();

        //leave this line
        System.out.println("Today is " + today);
    }
}
